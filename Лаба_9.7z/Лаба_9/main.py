import requests

url = 'https://httpbin.org/'

response = requests.options(url)
f_options = open('Options.txt', 'w', encoding="utf-8")
f_options.write(f'Код ответа сервера: {response.status_code} \n')
f_options.write(f'Заголовок ответа: {response.headers} \n')
f_options.write(f'Тело ответа: {response.text}')
f_options.close()

response = requests.get(url)
f_get = open('Get.txt', 'w', encoding="utf-8")
f_get.write(f'Код ответа сервера: {response.status_code} \n')
f_get.write(f'Заголовок ответа: {response.headers} \n')
f_get.write(f'Тело ответа: {response.text} \n')
f_get.write(f'Текст запроса: {response.content}')
f_get.close()

response = requests.post(url, data={'key': 'value'})
f_post = open('Post.txt', 'w', encoding="utf-8")
f_post.write(f'Код ответа сервера: {response.status_code} \n')
f_post.write(f'Заголовок ответа: {response.headers} \n')
f_post.write(f'Тело ответа: {response.text} \n')
f_post.write(f'Текст запроса: {response.content}')
f_post.close()